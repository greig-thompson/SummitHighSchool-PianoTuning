<?php 
    $pagetitle="Donations";
    include 'header.html'; 
?>
	<article>
		<h1><?php echo $pagetitle; ?></h1>
		<p>
			The Alyce Hatch Board of Directors would like to thank everyone who has contributed to our previous campaigns. All funds are used locally
			for services, supplies, equipment and maintenance of THE ALYCE HATCH CENTER where vital programs are provided to children and their families 
			from birth to five who are at risk of or who have developmental delays. Donations for our current Fundraising Campaign are welcome. In addition
			to funding ongoing operations, a FAMILY AID FUND has been established to help families in need to obtain services or items. Any size donation can 
			help a family get special equipment for home, medicine, shoes or extra therapy sessions limited or not covered by insurance.
		</p>
		<p>
			If you wish to help us and make a donation …
		</p>
		<p>
			<strong>Please mail checks payable to “Alyce Hatch Center, Inc.” to:</strong>
		</p>
		<p>
			The Alyce Hatch Board of Directors<br>
			61535 S Hwy Suite 5-308<br>
			Bend, OR 97702
		</p>
		<p>
			<strong>Please donate securely using PayPal or Credit Card:<strong>
		</p>
		<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
			<input type="hidden" name="cmd" value="_s-xclick">
			<input type="hidden" name="hosted_button_id" value="E2RF8RTG5U8A8">
			<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
			<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
		</form>
		<p>
			<i>"When we give cheerfully and accept gratefully, everyone is blessed."<i> - Maya Angelou
		</p>
		<br class="clear">
	</article>
<?php 
	include 'footer.html'; 
?>