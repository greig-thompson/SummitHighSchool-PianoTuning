<?php 
    $pagetitle="Error 403";
    include 'header.html'; 
?>
	<article>
		<h1><?php echo $pagetitle; ?></h1>
		<p>You recived an Error 403. This can be caused by an incorrect url or a glitch on our side. Try <a href="../index.php">Alyce Hatch</a>. If this doesn't work contact us.</p>
		<br class="clear">
	</article>
<?php 
	include 'footer.html'; 
?>