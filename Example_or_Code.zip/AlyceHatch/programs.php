<?php 
    $pagetitle="Programs";
    include 'header.html'; 
?>
	<article>
		<h1><?php echo $pagetitle; ?></h1>
		<aside>
			<figure class="slidebox">
				<img src="<?php echo $sitepath; ?>ahc-children-playing.jpg" alt="A photo children at play" title="&copy; Alyce Hatch Center 2017">
				<img src="<?php echo $sitepath; ?>ahc-child-stroller.jpg" alt="A photo of a child in a stroller" title="&copy; Alyce Hatch Center 2017">
				<img src="<?php echo $sitepath; ?>ahc-classroom-photo.jpg" alt="A photo of a alyce hatch classroom" title="&copy; Alyce Hatch Center 2017">
				<img src="<?php echo $sitepath; ?>ahc-child-at-play.jpg" alt="A photo a child at play" title="&copy; Alyce Hatch Center 2017">
			</figure>
		</aside>
		<p>The Alyce Hatch Center encompasses programs for children birth to 5 years of age with disabilities or developmental delays. Therapy and educational services are provided through direct, consultation and parent coaching methods. Services offered consist of:</p>
				<br>
				<ul>
					<li>Preschool Programs staffed by certified teachers</li>
					<li>Speech and Language Therapy</li>
					<li>Physical Therapy</li>
					<li>Occupational Therapy</li>
					<li>Vision Services</li>
					<li>Hearing Services</li>
					<li>Autism Services</li>
					<li>Assistive Technology including <br>Augmentative Communication</li>
				</ul>
				<p>We are also pleased to invite community peers into our high quality preschools. <a style="color:#FCFCFC" href="pdf_files/PreschoolBrochure.pdf" target="_blank">Click here for
				more information</a>.</p>
				<p>The Alyce Hatch Center serves as Central Oregon’s core location for Early Intervention (EI) and
				Early Childhood Special Education Programs (ECSE). It is the central office for our intake staff
				(who take initial referrals), our Deschutes and Crook County evaluation team, administrative
				staff and highly qualified staff serving the children who qualify for Early Intervention and
				Early Childhood Special Education in Bend. The center is the hub for its satellite locations in
				Redmond, LaPine, Prineville, Madras and Warm Springs.<br><br><br>
				The certified teachers and licensed therapeutic professionals of The Alyce Hatch Center nurture
				hundreds of children and their families per year to improved emotional, physical and social
				health.<br><br><br>
				The Alyce Hatch Center provides care that is centered on the entire family. After a child is
				made eligible for services, goals and services are prescribed through an Individualized Family
				Service Plan. This provides an individualized plan for each child to receive the care and
				attention that he or she needs to learn, grow and thrive. Additionally, his or her parents get the
				support, information and help that they need to do the best job possible for their child.<br><br><br>
				ECSE services may be provided at ECSE preschools, community sites, local preschools and
				Head Start locations in Central Oregon.</p>
			<img src="<?php echo $sitepath; ?>programs.gif">
		<br class="clear">
	</article>
<?php 
	include 'footer.html'; 
?>