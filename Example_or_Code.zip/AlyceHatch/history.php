<?php 
    $pagetitle="History";
    include 'header.html'; 
?>
	<article>
		<h1><?php echo $pagetitle; ?></h1>
		<aside>
			<img src="<?php echo $sitepath; ?>ahc-boy-playing-320.jpg" alt="Photo of Boy Playing" title="&copy; Alyce Hatch Center 2017" srcset="<?php echo $sitepath; ?>ahc-boy-playing-320.jpg 320w, <?php echo $sitepath; ?>ahc-boy-playing-640.jpg 640w, <?php echo $sitepath; ?>ahc-boy-playing-1080.jpg 1080w" sizes="(max-width: 480px) 100vw, (max-width: 900px) 33vw, 254px" class="shape">
		</aside>
		<p style="width: 400; margin-bottom: 0">
			For most people, it’s impossible to imagine what it would be like raising a
			child with special needs. For those families who have a child with special
			needs, the challenges seem overwhelming. In Bend, being very rural in nature
			in the 1970’s, the challenges were even more overwhelming due to the minimal
			resources available in the Central Oregon area. This forced families to travel
			to the Portland area and farther, in some cases, for specialized help. The
			community realized a crucial need and the idea for specialized therapy for
			children and training for parents was born.
		</p>
		<p>
			 A board of directors for the Preschool for Developmentally Disabled
			Children, supporting children 3 years to 5 years, was formed. Judy Hatch,
			Susie Hatch, and Marilyn Robinson, members of the board, coordinated
			space in the basement of the Methodist Church. With the support of other
			agencies and individuals, therapy and training groups for families 
			throughout Central Oregon were provided.
		</p>
		<p>
			Alyce Hatch was an active volunteer in the community at various churches,
			schools, and agencies.  She was sought after by many individuals and 
			organizations for her gentleness and her caring personality.  Over the years,
			Alyce joyfully accepted being a God-Mother to  over 50 children around
			the community.  Sadly, in 1984, Alyce passed away and the  community
			mourned a great loss.
		</p>
		<p>
			At that time the preschool was quickly outgrowing the basement of
			the Methodist Church.  Alyce Hatch’s family gathered together to discuss
			what options were available to preserve Alyce’s memory in the community.
			From that meeting, Robert Hatch, donated $50,000 to build a new structure
			for the preschool in memory of Alyce. With that seed planted, the
			community began working together to bring the Alyce Hatch Center to
			bloom.
		</p>
		<p>
			Local contractors, businesses, and individuals came together to
			purchase the land, design the architecture, donate time and/or materials
			to build the building, and create the playground.  The entire facility
			was built with local support with kids in mind, adding a perfect
			atmosphere for early childhood development.  In 1985, staff and children
			were moved in to begin therapy programs. And the Alyce Hatch Center
			became a reality.
		</p>
		<p>
			Since that time, the Alyce Hatch Center has served as Central 
			Oregon’s core location for Early Childhood Development.  Now, 17 years later,
			the board of directors consists of ten community members,
			two of them being Alyce Hatch’s daughter and granddaughter.
			It now encompasses programs for children birth to 5 years of
			age for children with disabilities, developmental delays, and
			children at risk.  With the incredible growth of Central Oregon,
			the programs for children have outgrown the current facility.
			And once again, the community is coming together to support 
			the Alyce Hatch Expansion Project.
		</p>
		<center><img style="width:50%;height:auto;" src="<?php echo $sitepath; ?> alyce-hatch-family-photo-320.jpg" alt="Photo of the Hatch Family" title="&copy; Alyce Hatch Center 2017" srcset="<?php echo $sitepath; ?>alyce-hatch-family-photo-320.jpg 320w, <?php echo $sitepath; ?>alyce-hatch-family-photo-640.jpg 640w, <?php echo $sitepath; ?>alyce-hatch-family-photo-1080.jpg 1080w" sizes="(max-width: 480px) 100vw, (max-width: 900px) 33vw, 254px" class="shape"></center>
		<h2>The Story of Alyce Hatch</h2>
		<p>
			Alyce Hatch was an amazing woman. Our community was blessed with her gentle, caring
			personality. She faithfully voluneered in the community at various churches, schools,
			and agencies. Alyce was an active member of St. Frances Catholic Church. She was a 
			giving soul, inviting strangers to dinner if they needed a meal and volunteering her
			time to anyone in need. Over the years, Alyce joyfully accept being a Godmother to
			many children around the community. Sadley, in 1984 Alyce passed away and the community
			mourned a great loss.
		</p>
		<p>
			At that time the Preschool for Developmentally Disabled Children was outgrowing the basement
			of the Methodist Church, Alyce Hatch's family wanted to preserve her memory in the community.
			Her son, Robert Hatch, donated $50,000 to build a new structure for the preschool in memory
			of Alyce. The communitycame together to bring the Alyce Hatch Center to reality. Alyce Hatch's
			legacy lives on in this wonderful center!
		</p>
		<br class="clear">
	</article>
<?php 
	include 'footer.html'; 
?>