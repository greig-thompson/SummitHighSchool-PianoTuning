<?php 
    $pagetitle="Home";
    include 'header.html'; 
?>
	<article>
		<aside class="indexright">
			<iframe src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d91743.90240046414!2d-121.40421881343602!3d44.06277160683718!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x54b8c888642ad669%3A0x7c0b693906e7a89a!2salyce+hatch+center!3m2!1d44.062793!2d-121.33417899999999!5e0!3m2!1sen!2sus!4v1512007262808" width="500" height="450" frameborder="0" style="border:0;margin-right:auto;margin-left:auto;" allowfullscreen></iframe>
		</aside>
		<h1><?php echo $pagetitle; ?></h1>
			<address>
				<h2>Mail</h2>
				<p>Alyce Hatch Center</p>
				<p>1406 NW Juniper Street</p>
				<p>Bend, Oregon 97701</p>
				<br>
				<h2>Other</h2>
				<p>Phone: (541) 389-5437</p>
				<p>Fax: (541) 382-3901</p>
			</address>
		<h2>How to find us</h2>
		<p>The Alyce Hatch Center is located at the northeast corner of Newport Ave. and Juniper Street on Bend’s west side. &nbsp;Juniper Street is between the roundabout at NW 14th Street &amp; NW Newport Ave. and College Way. &nbsp;Juniper is the only street on the north side of Newport between NW 14th and College Way.</p>
		<?php
			$name = $_POST['firstlastname'];
			$email = $_POST['emailaddress'];
			$phone = $_POST['phone'];
			$web = $_POST['web'];
			$message = $_POST['message'];
			$from = $_POST['firstlastname']; 
			$to = 'keyc@oregonstate.edu'; 
			$subject = '[Resume;] inquiry';
			$human = $_POST['human'];
			
			$headers .= "Reply-To: <{$_POST['emailaddress']}>";
			$body = "$name $email from $web would like a call back at $phone. Their favorite marketing outlets include $social_msg. They sent this message: $message\n";
			
			if ($_POST['submit']) {
				if ($name != '' && $email != '') {
					if ($human == '4') {                 
						if (mail ($to, $subject, $body, $from)) { 
							echo '<p class="confirmation">Your message has been sent!</p>';
						} else { 
							echo '<p class="tryagain">Something went wrong. Please try again.</p>'; 
						} 
					} else if ($_POST['submit'] && $human != '4') {
						echo '<p class="tryagain">The form was cleared because you provided an incorrect Anti-Spam answer. Please try again. </p>';
					}
				} else {
					echo '<p class="tryagain">Please fill in all required fields.</p>';
				}
			}
		?>
		<form id="contact" action="index.php" method="post">
			<h2 style="text-align: center;">Contact us from this secure form.</h2>
			<fieldset class="contact">
				<legend>Contact Information</legend>
				<label for="firstlastname">First and Last Name</label>
				<input name="firstlastname" id="firstlastname" type="text" required placeholder="John Doe"  maxlength="32">
				<label for="emailaddress">Email Address</label>
				<input name="emailaddress" id="emailaddress" type="email" required placeholder="JohnDoe@example.com"  maxlength="32">
				<label for="phone">Phone Number</label>
				<input name="phone" id="phone" type="tel" placeholder="123-456-7890"  maxlength="12">
				<label for="web">Website</label>
				<input name="web" id="web" type="url" placeholder="https://JohnDoe.com"  maxlength="40">
			</fieldset>
			<fieldset class="subject">
				<legend>Message Purpose</legend>
				<label for="subject">Select a
					<select name="subject" id="subject" required="">
						<option value="">subject:</option>
						<option value="Donation">Donation</option>
						<option value="Question">Question</option>
						<option value="Personal">Personal</option>
					</select>
				</label>
			</fieldset>
			<fieldset class="message">
				<legend>Your Message</legend>
				<label for="message">Type up to 480 characters.</label>
				<textarea id="message" name="message" required placeholder="Text only" maxlength="480" ></textarea>
			</fieldset>
			<fieldset class="captcha">
				<legend>Captcha</legend>
				<p>To help prevent spam, answer this mathematical equation:</p>
				<label for="human">What is 2+2?
					<input name="human" id="human" required maxlength="1">
				</label>
				<label for="submit"></label>
				<input name="submit" id="submit" type="submit" value="Send">
				<label for="reset"></label>
				<input name="reset" id="reset" type="reset" value="Reset">
			</fieldset>
		</form>
		<br class="clear">
	</article>
<?php 
	include 'footer.html'; 
?>