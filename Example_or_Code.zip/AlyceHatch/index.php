<?php 
    $pagetitle="Home";
    include 'header.html'; 
?>
	<article>
		<h1><?php echo $pagetitle; ?></h1>
		<aside class="indexright">
			<img src="<?php echo $sitepath; ?>index-image-playground-child-320.jpg" alt="Child on the Playground" title="&copy; Alyce Hatch Center 2017" srcset="<?php echo $sitepath; ?>index-image-playground-child-320.jpg 320w, <?php echo $sitepath; ?>index-image-playground-child-640.jpg 640w, <?php echo $sitepath; ?>index-image-playground-child-1080.jpg 1080w" sizes="(max-width: 480px) 100vw, (max-width: 900px) 33vw, 254px" class="shape">
			<!--<address>
				<p>Alyce Hatch Center</p>
				<p>1406 NW Juniper Street</p>
				<p>Bend, Oregon 97701</p>
				<p>Phone: (541) 389-5437</p>
				<p>Fax: (541) 382-3901</p>
			</address>-->
			<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FAlyceHatchBoardofDirectors%2F&tabs=timeline&width=300&height=500&small_header=true&adapt_container_width=true&hide_cover=false&show_facepile=false&appId" width="300" height="400" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
		</aside>
		<br class="clear">
		<p>
			The Alyce Hatch Center, Inc. Mission Our goal is to ensure that all children, regardless of their challenges, have the opportunity to discover, 
			learn and to reach their fullest potential. Alyce Hatch Center Board of Directors is a group of volunteers from the community who are the landlords
			and stewards of the building which and who:
		</p>
		<ul>
			<li>Provide a well maintained, safe and enriching environment</li>
			<li>Provide financial assistance or help in any way we can to children and their families</li>
			<li>Support like-minded community organizations and programs</li>
		</ul>
		<p>
			The Alyce Hatch Center is the home of the Deschutes County Early Intervention Program, the Early Childhood Special Education Program, and the Special
			Needs Resource Center. These programs provide vital services to families with children from birth to age five who are at risk or who have developmental
			delays.
		</p>
		<p>
			The Alyce Hatch Center is a top-notch preschool for very special kids, each of whom has undergone a comprehensive evaluation to determine which activities
			will help them practice the particular skills that will benefit them the most. At the Alyce Hatch Center, special needs are attended to in an integrated, 
			comprehensive, and natural preschool environment.
		</p>
		<br class="clear">
	</article>
<?php 
	include 'footer.html'; 
?>