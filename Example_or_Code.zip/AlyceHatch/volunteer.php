<?php 
    $pagetitle="Volunteering";
    include 'header.html'; 
?>
	<article>
		<h1><?php echo $pagetitle; ?></h1>
		<aside class="indexright">
			<img src="<?php echo $sitepath; ?> ahc-volunteers-320.jpg" alt="Alyce Hatch Volunteers" title="&copy; Alyce Hatch Center 2017" srcset="<?php echo $sitepath; ?>ahc-volunteers-320.jpg 320w, <?php echo $sitepath; ?>ahc-volunteers-640.jpg 640w, <?php echo $sitepath; ?>ahc-volunteers-1080.jpg 1080w" sizes="(max-width: 480px) 100vw, (max-width: 900px) 33vw, 254px" class="shape">
		</aside>
		<p>If you would like to volunteer at the Alyce Hatch Center during the day, or if you would like to volunteer to help with Alyce Hatch Center projects, we would love to have you.</p>
		<p>For additional information about volunteering at the Alyce Hatch Center, please call (541) 389-5437</p>
		<p><a href="http://www.hdesd.org/departments/human-resources/documents/employment-and-volunteering/">volunteer form</a></p>
		<br class="clear">
	</article>
<?php 
	include 'footer.html'; 
?>