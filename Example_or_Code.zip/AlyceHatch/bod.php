<?php 
    $pagetitle="Home";
    include 'header.html'; 
?>
	<article>
		<aside class="indexright">
			<img style="width:90%;height:auto;" src="<?php echo $sitepath; ?>ahc-board-picture-320.jpg" alt="Photo of the Alyce Hatch Board of Directors" title="&copy; Alyce Hatch Center 2017" srcset="<?php echo $sitepath; ?>ahc-board-picture-320.jpg 320w, <?php echo $sitepath; ?>ahc-board-picture-640.jpg 640w, <?php echo $sitepath; ?>ahc-board-picture-1080.jpg 1080w" sizes="(max-width: 480px) 100vw, (max-width: 900px) 33vw, 254px" class="shape">
		</aside>
		<h1><?php echo $pagetitle; ?></h1>
				<h2>President: Andy Kizans</h2>
				<p>Andy is a Global Strategy Director for AT&T and has spent 20+ years in various international assignments.  Andy and his family returned to Bend in 2004 and are delighted to be back in Central Oregon with access to so many recreational pursuits.   His involvement with the Alyce Hatch Center began when they assessed his son who was born 7 weeks premature.  He found the work done by the staff and therapists to be outstanding and joined the Board of Directors in 2006.   He became President in 2009.</p>
				<h2>Vice President/secretary: Carla Hunt</h2>
				<p>Born and raised in Bend, Carla knew Alyce Hatch growing up and is still good friends with her daughter, and grandchilidren.&nbsp; She enjoys volunteering for special projects and started the Christmas ornaments back in 1993 which was a great fundraiser for 15 years. &nbsp;The collectible handmade pottery ornaments became an anticipated yearly tradition.  Carla has loved her 15 years on the Alyce Hatch Board of Directors.</p>
				<h2>Treasurer: Jody Schatz</h2>
				<p>Jody has lived in Bend for 35 years. She and her husband have owned Crane Prairie Resort for over 40 years. She has known the Hatch Family for over 30 years. Jody was very involved with Bend High while her children were growing up, and joined the Alyce Hatch Center Board of Directors about 1 ½ year ago as a way to get involved to give back to the local community. She has expertise in business accounting and is contributing those skill to the Board by acting as its treasurer. She is excited to be involved with the Alyce Hatch Center and its programs and hopes to be a part of its continued success.</p>
				<h2>Roger Singer</h2>
				<p>Roger has been providing financial planning services to corporations for almost 20 years through his consulting practice and to a limited number of individual clients for more than 30 years.  In August, 2000, Roger joined Merrill Lynch to focus on creating, growing and preserving his individual client’s wealth.<br />Roger has earned his Certified Financial Manager (CFM) designation and has B.S., M.S. and Ph.D degrees in chemistry from Ohio State University, Polytechnic Institute of Brooklyn and the University of Maryland respectively, and an MBA from Rensselaer Polytechnic Institute.  He resides in Bend, Oregon with his wife Arlene.  Roger has three grown children: Greg, Andrew and Amy.</p>
				<h2>Chris Key</h2>
				<p>Chris, originally from Ohio and now on his 2nd decade in Bend, brings a wealth of experience in health care, web development and project and operations management. He is a parent of a child with a disability and currently receiving services from the Alyce Hatch Center. From personal experience, Chris strongly believes in The Center's mission driving the delivery of vital developmental services to children and families in our community.</p>
				<h2>Kevin Shaver</h2>
				<p>Kevin was born and raised in bend, Oregon and is a Project Architect with BBT Architects.  Kevin grew up with Alyce Hatch's grandchildren, as his parents were long time friends with Alyce's daughter Ann and her Husband Harley Elkin.  Kevin had the opportunity to work on the expansion to the Alyce Hatch Center in 2003, from the early bond work to the completion of construction.  Kevin looks forward to expanding his relationship with the Center by continuing to assist the Center with the incredible services it provides by serving as a member of the Board of Directors.</p>
				<p>Interested in becoming a board member <a href="pdf_files/BoardofDirectorsApplication.pdf" target="_blank">Board Application</a>?</p>
		<br class="clear">
	</article>
<?php 
	include 'footer.html'; 
?>