<?php 
    $pagetitle="Testamonials";
    include 'header.html'; 
?>
	<article>
		<h1><?php echo $pagetitle; ?></h1>
		<aside>
			<img src="<?php echo $sitepath; ?> ahc-grad-student-320.jpg" alt="graduated student of Alyce Hatch downtown" title="&copy; Alyce Hatch Center 2017" srcset="<?php echo $sitepath; ?>ahc-grad-student-320.jpg 320w, <?php echo $sitepath; ?>ahc-grad-student-640.jpg 640w, <?php echo $sitepath; ?>ahc-grad-student-1080.jpg 1080w" sizes="(max-width: 480px) 100vw, (max-width: 900px) 33vw, 254px" class="shape">
		</aside>
		<p>What parents are saying...</p>
		<p>"The people that are involved are spectacular. They are our friends."</p>
		<p>"I love how much our child enjoys his time there and how well it works. The speech group is fun and makes him think about words, sounds, syllables, etc."</p>
		<p>"I think Bev, Lisa, Karla, Paula, Carol, and everyone else are doing great. My child is not the same as she was when we first began the program."</p>
		<p>"Great! Very helpful, compassionate, and energetic teachers."</p>
		<p>"Early childhood ed has been such a blessing to our family and our child."</p>
		<p>"It is a wonderful environment. He really enjoys his classroom and all the teachers and specialists."</p>
		<p>"I think that you provide a wonderful program - Thank you!"</p>
		<p>"My daughter has made tremendous strides socially, as well as emotionally and physically."</p>
		<p>"I couldn’t be more impressed or pleased with the one-on-one with every child and how each is known as an individual…"</p>
		<p>"We truly appreciate all that you do to help our children."</p>
		<br class="clear">
	</article>
<?php 
	include 'footer.html'; 
?>