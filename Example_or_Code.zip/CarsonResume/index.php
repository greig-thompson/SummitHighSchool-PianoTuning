<?php
	//PHP Vars
	$sitename = "R&eacute;sum&eacute;";
	$slogan = "Student of Engineering at Oregon State University";
	$sitepath = "http://people.oregonstate.edu/~keyc/about/";
	$author = "Carson Key";
?>
<!doctype html>
<!--[if lt IE 7 ]> <html class="ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]>    <html class="ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]>    <html class="ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]>    <html class="ie9" lang="en"> <![endif]-->
<html lang="en">
	<head>
		<!--Title-->
		<title><?php echo $author.", ".$sitename; ?></title>
		<!--Links-->
		<link href="https://necolas.github.io/normalize.css/3.0.3/normalize.css" type="text/css" rel="stylesheet" />
		<link href="Assests/main.css" rel="stylesheet">
		<link href="Assests/slideshow.css" type="text/css" rel="stylesheet" />
		<link href="https://fonts.googleapis.com/css?family=Alfa+Slab+One|Coda" rel="stylesheet">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<link rel="stylesheet" href="https://d1azc1qln24ryf.cloudfront.net/114779/Socicon/style-cf.css?rd5re8" />
		<!--Meta Tags-->
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta name="keywords" content="Carson Key, Carson Key Resume, OSU Student, Engineering Student, CS Student, Computer Science Student, Oregon State University Student, Oregon State Student, Computer Science Major, CS Major, Oregon State Programmer, OSU Programmer, Web Disigner, General Programmer, Netwrok Programmer, Security Programmer, C++ Programmer, Python Programmer, Android Developer, IOS Developer">
		<meta name="author" content="<?php echo $author; ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="<?php echo $slogan; ?>">
		<meta name="robots" content="noindex, nofollow, noarchive">
		<!--Favicons-->
		<link rel="apple-touch-icon" sizes="180x180" href="Assests/Favicon/apple-touch-icon.png">
		<link rel="icon" type="image/png" sizes="32x32" href="Assests/Favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="16x16" href="Assests/Favicon/favicon-16x16.png">
		<link rel="manifest" href="Assests/Favicon/manifest.json">
		<link rel="mask-icon" href="Assests/Favicon/safari-pinned-tab.svg" color="#567d2b">
		<link rel="shortcut icon" href="Assests/Favicon/favicon.ico">
		<meta name="msapplication-config" content="Assests/Favicon/browserconfig.xml">
		<meta name="theme-color" content="#ffffff">
	</head>
	<body>
		<header id="top">
			<!--Header Tags-->
			<a href="<?php echo $sitepath?>">
				<img src="Assests/symbol.png" alt="<?php echo $sitename." for ".$author; ?>" title="<?php echo $slogan; ?>" id="symbol" class="symbol drop-shadow move"/><img src="Assests/carson.png" alt="<?php echo $sitename." for ".$author; ?>" title="<?php echo $slogan; ?>" id="firstname" class="hfirst drop-shadow move"/><br><img src="Assests/key.png" alt="<?php echo $sitename." for ".$author; ?>" title="<?php echo $slogan; ?>" id="lastname" class="hlast drop-shadow move"/><img src="Assests/carson-key-symbol.png" alt="<?php echo $sitename." for ".$author; ?>" title="<?php echo $slogan; ?>" id="combo" class="hcombo"/>
			</a>
			<!--<h1><?php //echo $author." For ".$sitename; ?></h1>-->
			<p style="text-align: center;" class="move"><?php echo $slogan; ?></p>
			<!--NAV Bar-->
			<nav id="articles">
				<!--Unorderd List-->
				<ul>
					<!--Unorderd List Tags-->
					<li class="radius" ><a href="#about" class="scroll" data-speed="2000" style="background-color: #1E2C13;"><i class="material-icons move">info</i>About</a></li>
					<li class="radius"><a href="#education" class="scroll" data-speed="2000"><i class="material-icons move">account_balance</i>Education</a></li>
					<li class="radius"><a href="#work" class="scroll" data-speed="2000" style="background-color: #1E2C13; color: #704A40;"><i class="material-icons move">work</i>Work Experience</a></li>
					<li class="radius"><a href="#service" class="scroll" data-speed="2000" style="color: #C2E0EB; background-color: rgba(86, 125, 43, 0.86);"><i class="material-icons move">language</i>Service</a></li>
					<li class="radius"><a href="#skills" class="scroll" data-speed="2000" style="color: #704A40;background-color: rgba(175, 161, 135, 0.86);"><i class="material-icons move">build</i>Skills</a></li>
					<li class="radius"><a href="#fun" class="scroll" data-speed="2000"  style="background-color: #C2E0EB; color: #567D2B;"><i class="material-icons move">stars</i>Fun</a></li>
				</ul>
			</nav>
		</header>
		<main>
			<!--About-->
			<article id="about">
				<aside style="width:50%;">
					<h2>About</h2>
					<p class="alignright">My name is Carson, and I'm a freshman at oregon state university. I am currently majoring in computer science. I really enjoy programming. It's my pass time, and my work. I have been programming for eight years now: ever since I was ten years old. I have programmed in 36 different programming languages.</p>
					<figure class="red-bg">
						<img src="Assests/carson-key-self-portrait-2017-320.jpg" alt="<?php echo $author; ?> self portrait" title="&copy; <?php echo $author; ?> 2017" srcset="Assests/carson-key-self-portrait-2017-320.jpg 320w, Assests/carson-key-self-portrait-2017-640.jpg 640w, Assests/carson-key-self-portrait-2017-1080.jpg 1080w" sizes="(max-width: 480px) 100vw, (max-width: 900px) 33vw, 254px" class="shape">
						<figcaption class="tan"><?php echo $author; ?> self portrait</figcaption>
					</figure>
				</aside>
				<h2>Contact</h2>
				<address>
					<a href="<?php echo $sitepath ?>"><?php $author ?></a>
					<p>1003 Kelly Engineering Center</p>
					<p>Corvalis, Oregon, 97330</p>
					<p>541-617-1343</p>
					<a href="#contact" class="scroll">Contact me using the form below &darr;</a>
				</address>
				<br class="clear">
			</article>
			<!--Article Two-->
			<article id="education" class="red-bg">
				<h2 style="color: #1E2C13;">Education</h2>
				<dl style="float:right;width:50%;">
					<dt style="color: #AFA187;">Bacholars of Science in Computer Sciences</dt>
						<dd><a href="http://engineering.oregonstate.edu/" target="_blank">Oregon State University</a></dd>

					<dt style="color: #AFA187;">Honors Diploma</dt>
						<dd><a href="https://www.bend.k12.or.us/summit" target="_blank">Summit High School</a></dd>
				</dl>
				<figure class="slidebox">
					<img src="Assests/carson-key-app-cal-200.jpg" alt="A photo of some python code I wrote" title="&copy; <?php echo $author; ?> 2017">
					<img src="Assests/carson-key-app-info-1-200.jpg" alt="A photo of my laptop" title="&copy; <?php echo $author; ?> 2017">
					<img src="Assests/carson-key-app-info-2-200.jpg" alt="A photo of my laptop" title="&copy; <?php echo $author; ?> 2017">
					<img src="Assests/carson-key-app-leader-200.jpg" alt="A photo of my laptop" title="&copy; <?php echo $author; ?> 2017">
					<figcaption>Education Expereince</figcaption>
				</figure>
			</article>
			<!--Article Three-->
			<article id="work">
				<h2 class="tan">Work Expereince</h2>
				<dl>
					<dt class="red">PlaceHolder</dt>
						<dd class="red">Other PlaceHolder</dd>
				</dl>
			</article>
			<!--Article Four-->
			<article id="service" style="background-color: rgba(86, 125, 43, 0.86);">
				<h2>Service to the community</h2>
				<dl>
					<dt style="color: #C2E0EB;">placeholder</dt>
						<dd style="color: #C2E0EB;">placeholeder two</dd>
				</dl>
				<figure>
					<figcaption>Test Video of An App</figcaption>
					<iframe src="https://www.youtube.com/embed/iI5ZwTzUTmY" frameborder="0" allowfullscreen></iframe>
				</figure>
			</article>
			<!--Article Five-->
			<article id="skills" style="background-color: rgba(175, 161, 135, 0.86);">
				<h2 style="color: #704A40;">Skills and Proficiencies</h2>
				<table sortable id="sort" class="sort">
					<caption style="color: #704A40;">technical Skills</caption>
					<thead>
						<th style="color: #704A40;">Skills</th>
						<th style="color: #704A40;">1+ years</th>
						<th style="color: #704A40;">5+ years</th>
						<th style="color: #704A40;">10+ years</th>
						<th style="color: #704A40;">15+ years</th>
					</thead>
					<tbody>
						<tr>
							<th class="no-sort skill" style="color: #704A40;">HTML, CSS, PHP</th>
							<td colspan="3">12 years of experience</td>
							<td>(I've been developing since I was 6)</td>
						</tr>
						<tr>
							<th class="no-sort skill" style="color: #704A40;">Java</th>
							<td colspan="2">8 years of experience</td>
							<td></td>
							<td></td>
						</tr>
						<tr>
							<th class="no-sort skill" style="color: #704A40;">SQL</th>
							<td colspan="2">8 years of experience</td>
							<td></td>
							<td></td>
						</tr>
						<tr>
							<th class="no-sort skill" style="color: #704A40;">Python</th>
							<td colspan="2">8 years of experience</td>
							<td></td>
							<td></td>
						</tr>
						<tr>
							<th class="no-sort skill" style="color: #704A40;">VB,VB.net</th>
							<td colspan="2">7 years of experience</td>
							<td></td>
							<td></td>
						</tr>
						<tr>
							<th class="no-sort skill" style="color: #704A40;">C, C#</th>
							<td colspan="2">6 years of experience</td>
							<td></td>
							<td></td>
						</tr>
						<tr>
							<th class="no-sort skill" style="color: #704A40;">Ruby</th>
							<td colspan="2">6 years of experience</td>
							<td></td>
							<td></td>
						</tr>
						<tr>
							<th class="no-sort skill" style="color: #704A40;">C++</th>
							<td colspan="2">5 years of experience</td>
							<td></td>
							<td></td>
						</tr>
						<tr>
							<th class="no-sort skill" style="color: #704A40;">Linux Systems</th>
							<td colspan="1">4 years of experience</td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
						<tr>
							<th class="no-sort skill" style="color: #704A40;">Server/Network Systems</th>
							<td colspan="1">3 years of experience</td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
						<tr>
							<th class="no-sort skill" style="color: #704A40;">Cyber Security</th>
							<td colspan="1">3 years of experience</td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
					</tbody>
					<tfoot>
						<tr>
							<th colspan="4"></th>
						</tr>
					</tfoot>
				</table>
			</article>
			<!--Fun-->
			<article id="fun" class="masonry" style="background-color: rgba(194, 224, 235, 0.86);">
				<h2>Fun</h2>
				<p>this gallery contains a photo of my laptop and microphone. These two photos are here because I love technology. The other photos are of a b-17 I went to this summer. This photos are her because I love history and WWII history is my favorite.</p>
				<img src="Assests/carson-key-mic-photo-400.jpg" alt="A photo of my Blue Yeti Microphone" title="&copy; <?php echo $author; ?> 2017" class="caption">
				<img src="Assests/carson-key-foreground-laptop-400.jpg" alt="A photo of my laptop" title="&copy; <?php echo $author; ?> 2017" class="caption">
				<img src="Assests/carso-key-b17-bomber-room-400.jpg" alt="A photo of a b-17 bomber room" title="&copy; <?php echo $author; ?> 2017" class="caption">
				<img src="Assests/carson-key-b17-backside-400.jpg" alt="A photo of a b-17" title="&copy; <?php echo $author; ?> 2017" class="caption">
				<img src="Assests/carson-key-b17-back-side-tail-400.jpg" alt="A photo of a b-17 tail" title="&copy; <?php echo $author; ?> 2017" class="caption">
				<img src="Assests/carson-key-b17-comm-radio-400.jpg" alt="A photo of a b-17 communication radio" title="&copy; <?php echo $author; ?> 2017" class="caption">
				<img src="Assests/carson-key-b17-cockpit-400.jpg" alt="A photo of a b-17 cockpit" title="&copy; <?php echo $author; ?> 2017" class="caption">
				<img src="Assests/carson-key-b17-front-side-400.jpg" alt="A photo of a b-17 side art" title="&copy; <?php echo $author; ?> 2017" class="caption">
				<img src="Assests/carson-key-b17-radion-400.jpg" alt="A photo of a b-17 radio" title="&copy; <?php echo $author; ?> 2017" class="caption">
				<img src="Assests/carson-key-b17-front-photo-400.jpg" alt="A photo the front of a b-17" title="&copy; <?php echo $author; ?> 2017" class="caption">
			</article>
		<?php
			$name = $_POST['firstlastname'];
			$email = $_POST['emailaddress'];
			$phone = $_POST['phone'];
			$web = $_POST['web'];
			$message = $_POST['message'];
			$from = $_POST['firstlastname']; 
			$to = 'keyc@oregonstate.edu'; 
			$subject = '[Resume;] inquiry';
			$human = $_POST['human'];
			
			$headers .= "Reply-To: <{$_POST['emailaddress']}>";
			$body = "$name $email from $web would like a call back at $phone. Their favorite marketing outlets include $social_msg. They sent this message: $message\n";
			
			if ($_POST['submit']) {
				if ($name != '' && $email != '') {
					if ($human == '4') {                 
						if (mail ($to, $subject, $body, $from)) { 
							echo '<p class="confirmation">Your message has been sent!</p>';
						} else { 
							echo '<p class="tryagain">Something went wrong. Please try again.</p>'; 
						} 
					} else if ($_POST['submit'] && $human != '4') {
						echo '<p class="tryagain">The form was cleared because you provided an incorrect Anti-Spam answer. Please try again. </p>';
					}
				} else {
					echo '<p class="tryagain">Please fill in all required fields.</p>';
				}
			}
		?>
		<form id="contact" action="index.php" method="post">
			<h2 style="text-align: center; color: #AFA187;">Contact me via this secure form.</h2>
			<fieldset>
				<legend>Contact Information</legend>
				<label for="firstlastname">First and Last Name</label>
				<input name="firstlastname" id="firstlastname" type="text" required placeholder="John Doe"  maxlength="32">
				<label for="emailaddress">Email Address</label>
				<input name="emailaddress" id="emailaddress" type="email" required placeholder="JohnDoe@example.com"  maxlength="32">
				<label for="phone">Email Address</label>
				<input name="phone" id="phone" type="tel" placeholder="123-456-7890"  maxlength="12">
				<label for="web">Email Address</label>
				<input name="web" id="web" type="url" placeholder="https://JohnDoe.com"  maxlength="40">
			</fieldset>
			<fieldset>
				<legend>Message Purpose</legend>
				<label for="subject">Select a
					<select name="subject" id="subject" required="">
						<option value="">subject:</option>
						<option value="Employment">Employment</option>
						<option value="Contract">Contract</option>
						<option value="Personal">Personal</option>
					</select>
				</label>
			</fieldset>
			<fieldset>
				<legend>Your Message</legend>
				<label for="message">Type up to 480 characters.</label>
				<textarea id="message" name="message" required placeholder="Text only" maxlength="480" ></textarea>
			</fieldset>
			<fieldset>
				<legend>Captcha</legend>
				<p>To help prevent spam, answer this mathematical equation:</p>
				<label for="human">What is 2+2 ?
				<input name="human" id="human" required maxlength="1">
				</label>
				<label for="submit"></label>
				<input name="submit" id="submit" type="submit" value="Send">
				<label for="reset"></label>
				<input name="reset" id="reset" type="reset" value="Reset">
			</fieldset>
		</form>
		</main>
		<footer>
			<ul>
				<li><?php echo date('F j, Y',filemtime($_SERVER['SCRIPT_FILENAME'])) ?></li>
				<li>&copy; 2017-<?php echo date('Y').' '.$author; ?></li>
				<li><a href="#top" class="scroll" data-speed="1000">Top</a></li>
			</ul>
			<nav id="share">
				<i class="material-icons">share</i>
				<a href="" target="_blank"><i class="socicon-github"></i></a>
				<a href="" target="_blank"><i class="socicon-facebook"></i></a>
				<a href="" target="_blank"><i class="socicon-twitter"></i></a>
				<a href="" target="_blank"><i class="socicon-snapchat"></i></a>
			</nav>
		</footer>
		<!--Scripts-->
		<script type="text/javascript" src="Assests/modernizr-dev-min.js"></script> <!--Modnizer-->
		<script type="text/javascript" src="Assests/smoothscroll.js"></script> <!---Scroll-->
		<script src='Assests/tablesort.min.js'></script>
		<script>
			new Tablesort(document.getElementById('sort'));
		</script>
		<script>
			var bgArray = ['Assests/carson-key-austin-hall-blur-1080.jpg','Assests/carson-key-background-design-1080.jpg'],
				selectBG = bgArray[Math.floor(Math.random() * bgArray.length)];
			if (document.documentElement.clientWidth > 4000) {
				document.body.style.backgroundImage = 'url(' + selectBG + ')';
			}
		</script>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>    
		<script src="Assests/jquery.captionate.js"></script>    
		<script>
			// North Krimsly: wait until images have all loaded so we can properly get their width
			$(window).load(function(){  
				$('img.caption').captionate();
			});
		</script>
	</body>
</html>