<?php
	//PHP Vars
	$sitename = "R&eacute;sum&eacute;";
	$slogan = "Student of Engineering at Oregon State University";
	$sitepath = "http://people.oregonstate.edu/~keyc/about/";
	$author = "Carson Key";
?>
<!doctype html>
<html lang="en">
	<head>
		<!--Title-->
		<title><?php echo $author.", ".$sitename; ?></title>
		<!--Links-->
		<link href="Assests/main.css" rel="stylesheet">
		<link href="Assests/slideshow.css" type="text/css" rel="stylesheet" />
		<link href="https://fonts.googleapis.com/css?family=Alfa+Slab+One|Coda" rel="stylesheet">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<link rel="stylesheet" href="https://d1azc1qln24ryf.cloudfront.net/114779/Socicon/style-cf.css?rd5re8" />
		<!--Meta Tags-->
		<meta charset="UTF-8">
		<meta name="keywords" content="Carson Key, Carson Key Resume, OSU Student, Engineering Student, CS Student, Computer Science Student, Oregon State University Student, Oregon State Student, Computer Science Major, CS Major, Oregon State Programmer, OSU Programmer, Web Disigner, General Programmer, Netwrok Programmer, Security Programmer, C++ Programmer, Python Programmer, Android Developer, IOS Developer">
		<meta name="author" content="<?php echo $author; ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="<?php echo $slogan; ?>">
		<meta name="robots" content="noindex, nofollow, noarchive">
		<!--Favicons-->
		<link rel="apple-touch-icon" sizes="180x180" href="Assests/Favicon/apple-touch-icon.png">
		<link rel="icon" type="image/png" sizes="32x32" href="Assests/Favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="16x16" href="Assests/Favicon/favicon-16x16.png">
		<link rel="manifest" href="Assests/Favicon/manifest.json">
		<link rel="mask-icon" href="Assests/Favicon/safari-pinned-tab.svg" color="#567d2b">
		<link rel="shortcut icon" href="Assests/Favicon/favicon.ico">
		<meta name="msapplication-config" content="Assests/Favicon/browserconfig.xml">
		<meta name="theme-color" content="#ffffff">
	</head>
	<body>
		<header id="top">
			<!--Header Tags-->
			<a href="<?php echo $sitepath?>">
				<img src="Assests/symbol.png" alt="<?php echo $sitename." for ".$author; ?>" title="<?php echo $slogan; ?>" id="symbol" class="symbol drop-shadow move"/><img src="Assests/carson.png" alt="<?php echo $sitename." for ".$author; ?>" title="<?php echo $slogan; ?>" id="firstname" class="hfirst drop-shadow move"/><br><img src="Assests/key.png" alt="<?php echo $sitename." for ".$author; ?>" title="<?php echo $slogan; ?>" id="lastname" class="hlast drop-shadow move"/><img src="Assests/carson-key-symbol.png" alt="<?php echo $sitename." for ".$author; ?>" title="<?php echo $slogan; ?>" id="combo" class="hcombo"/>
			</a>
			<!--<h1><?php //echo $author." For ".$sitename; ?></h1>-->
			<p style="text-align: center;" class="move"><?php echo $slogan; ?></p>
			<!--NAV Bar-->
			<nav id="articles">
				<!--Unorderd List-->
				<ul>
					<!--Unorderd List Tags-->
					<li class="radius" ><a href="#about" class="scroll" data-speed="2000" style="background-color: #1E2C13;"><i class="material-icons move">info</i>About</a></li>
					<li class="radius"><a href="#education" class="scroll" data-speed="2000"><i class="material-icons move">account_balance</i>Education</a></li>
					<li class="radius"><a href="#work" class="scroll" data-speed="2000" style="background-color: #1E2C13; color: #704A40;"><i class="material-icons move">work</i>Work Experience</a></li>
					<li class="radius"><a href="#service" class="scroll" data-speed="2000" style="color: #C2E0EB; background-color: rgba(86, 125, 43, 0.86);"><i class="material-icons move">language</i>Service</a></li>
					<li class="radius"><a href="#skills" class="scroll" data-speed="2000" style="color: #704A40;background-color: rgba(175, 161, 135, 0.86);"><i class="material-icons move">build</i>Skills</a></li>
					<li class="radius"><a href="#fun" class="scroll" data-speed="2000"  style="background-color: #C2E0EB; color: #567D2B;"><i class="material-icons move">stars</i>Fun</a></li>
				</ul>
			</nav>
		</header>
		<main>
			<!--About-->
			<article id="about">
				<h2>Error 403 - Forbidden</h2>
				<p>Forbidden, retry to connect to website by clicking this <a href="index.php">link</a></p>
			</article>
		</main>
	</body>
<html>